# KING Detection v1.0

Experimental magnetometer scanning and room calibration app. Not a validated hidden-camera detector.

## Build in GitHub Actions
Upload **the contents** of this folder to the root of the GitHub repository (not the ZIP itself). The `.github/workflows/android-apk.yml` workflow builds an unsigned-for-store but installable **debug APK** automatically on push to main. Download the artifact from **Actions > Build KING Detection APK > latest run > Artifacts**. Unzip the artifact to obtain `app-debug.apk`.

The Android build needs network access to Google/Maven repositories. No compiled APK is included.
