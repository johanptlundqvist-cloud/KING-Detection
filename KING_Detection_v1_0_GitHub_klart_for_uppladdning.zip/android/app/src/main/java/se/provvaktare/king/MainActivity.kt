package se.provvaktare.king

import android.app.Activity
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale

class MainActivity : Activity(), SensorEventListener {
    private lateinit var web: WebView
    private lateinit var sensors: SensorManager
    private var magnetic: Sensor? = null
    private var rotation: Sensor? = null
    private var steps: Sensor? = null
    private var magOn = false
    private var motionOn = false
    private val rot = FloatArray(9)
    private val orientation = FloatArray(3)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
        magnetic = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        rotation = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        steps = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "NativeSensor")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        @JavascriptInterface fun start() = runOnUiThread { magOn = true; register() }
        @JavascriptInterface fun stop() = runOnUiThread { magOn = false; register() }
        @JavascriptInterface fun available(): Boolean = magnetic != null
        @JavascriptInterface fun motionAvailable(): Boolean = rotation != null && steps != null
        @JavascriptInterface fun startMotion() = runOnUiThread { motionOn = true; register() }
        @JavascriptInterface fun stopMotion() = runOnUiThread { motionOn = false; register() }
    }
    private fun register() {
        sensors.unregisterListener(this)
        if (magOn || motionOn) magnetic?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (motionOn) {
            rotation?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            steps?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }
    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val v = event.values
                val js = String.format(Locale.US,"updateField(%.5f,%.5f,%.5f)",v[0],v[1],v[2])
                web.evaluateJavascript(js, null)
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rot, event.values)
                SensorManager.getOrientation(rot, orientation)
                val degrees = (Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0
                web.evaluateJavascript(String.format(Locale.US,"nativePose(%.3f)",degrees),null)
            }
            Sensor.TYPE_STEP_DETECTOR -> web.evaluateJavascript("nativeStep()",null)
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onPause() { sensors.unregisterListener(this); super.onPause() }
    override fun onResume() { super.onResume(); if (::sensors.isInitialized) register() }
    override fun onDestroy() { sensors.unregisterListener(this); web.destroy(); super.onDestroy() }
}
