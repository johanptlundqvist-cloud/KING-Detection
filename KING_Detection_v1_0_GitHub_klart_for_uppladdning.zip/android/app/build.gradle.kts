plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "se.provvaktare.king"; compileSdk = 35
 defaultConfig { applicationId = "se.provvaktare.king"; minSdk = 26; targetSdk = 35; versionCode = 10; versionName = "1.0" } }
