# Provvaktare KING – version 0.7

## Syfte
Ett snabbt, enkelt arbetsstöd för provvakter: förbered provet, genomför två experimentella magnetometerskanningar, ta emot elever, håll provtiden och dokumentera avslutet. Gränssnittet visar ett steg i taget med bildstöd och stora knappar. Elevantal kan anges som intervall eller hoppas över.

## Utvecklarprofil
Projektinitiativtagaren är en svensk matematiklärare på högstadiet med cirka sju års lärarerfarenhet och bakgrund som maskiningenjör. Kombinationen av matematik, teknik och vardagsnära skolbehov ligger bakom ambitionen att bygga ett matematiskt avancerat analysstöd som är mycket enkelt att använda. Personliga familje- och hälsouppgifter ingår inte eftersom de inte behövs för projektet.

## Matematik och begränsningar
En magnetometer mäter vektorn B=(Bx,By,Bz) i mikrotesla. Den skalära fältstyrkan är |B|=sqrt(Bx²+By²+Bz²). Grundmätning och kontrollmätning kan jämföras med median, absolut medianavvikelse (MAD), robust spridningsskattning sigma≈1,4826*MAD, avvikelsefrekvenser och tidsserieavstånd. Projektets tidigare analysmotor innehåller även Kalmanutjämning och begränsad dynamisk tidskrigering (DTW). I denna förenklade v0.7-vy visas en begriplig jämförelse av median och spridning.

Detta är avancerad signalbehandling, men **inte** en validerad detektor för gömda mobiltelefoner. Magnetiska avvikelser kan bero på metall, möbler, elektriska installationer, gångväg, telefonens orientering eller sensorns kalibrering. Resultat får inte användas som bevis för fusk eller för att peka ut elever.

## Byggstatus
Detta paket är ett Android Studio-byggprojekt, inte en färdig APK. En APK kan byggas med Android SDK/Gradle, exempelvis via det inkluderade GitHub Actions-arbetsflödet. Android-enhet och magnetometersensor krävs för att verifiera mätfunktionen. Originalfiguren från MatteKing har inte extraherats ur referens-APK:n och ingår därför inte i detta paket.
