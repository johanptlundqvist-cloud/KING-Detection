import SwiftUI
import CoreMotion

@main struct ProvvaktareKINGApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

@MainActor final class SensorModel: ObservableObject {
    @Published var magnitude: Double? = nil
    @Published var baseline: Double? = nil
    @Published var status = "Starta sensorn"
    private let manager = CMMotionManager()
    private var estimate: Double? = nil
    private var variance = 1.0
    func start() {
        guard manager.isMagnetometerAvailable else { status = "Magnetometer saknas"; return }
        manager.magnetometerUpdateInterval = 0.1
        manager.startMagnetometerUpdates(to: .main) { [weak self] data, error in
            guard let self, let b = data?.magneticField else { return }
            let measurement = sqrt(b.x*b.x + b.y*b.y + b.z*b.z)
            self.variance += 0.005
            let gain = self.variance / (self.variance + 0.1)
            let value = (self.estimate ?? measurement) + gain * (measurement - (self.estimate ?? measurement))
            self.variance *= (1 - gain)
            self.estimate = value
            self.magnitude = value
            if let baseline = self.baseline {
                self.status = abs(value - baseline) >= 15 ? "Magnetisk avvikelse – kontrollera miljön" : "Ingen större avvikelse"
            } else { self.status = "Kalibrera referens" }
        }
    }
    func calibrate() { baseline = magnitude }
    func stop() { manager.stopMagnetometerUpdates(); status = "Stoppad" }
}

struct ContentView: View {
    @StateObject private var sensor = SensorModel()
    @State private var seconds = 3600
    @State private var running = false
    let tick = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Experimentell magnetisk avvikelsemätning").font(.headline)
                    Text(sensor.magnitude.map { String(format: "%.1f µT", $0) } ?? "— µT").font(.system(size: 44, weight: .bold, design: .rounded))
                    Text(sensor.status)
                    HStack { Button("Starta") { sensor.start() }; Button("Kalibrera") { sensor.calibrate() }; Button("Stoppa") { sensor.stop() } }.buttonStyle(.borderedProminent)
                    Divider()
                    Text("Provtimer").font(.headline)
                    Text(String(format: "%02d:%02d", seconds / 60, seconds % 60)).font(.system(size: 44, weight: .bold, design: .monospaced))
                    HStack { Button(running ? "Pausa" : "Starta") { running.toggle() }; Button("Återställ") { running = false; seconds = 3600 } }.buttonStyle(.bordered)
                    Divider()
                    Text("Mätningen kan inte avgöra om en elev har en dold telefon. Metallföremål och installationer ger också utslag.").font(.footnote).foregroundStyle(.secondary)
                }.padding()
            }.navigationTitle("Provvaktare KING")
        }.onReceive(tick) { _ in if running && seconds > 0 { seconds -= 1 } }
    }
}
