# KING Detection – matematik och fysik

- Magnetisk fältstyrka: `|B|=sqrt(Bx²+By²+Bz²)` i mikrotesla.
- Samplingshastighet: begränsar antal behandlade mätningar per sekund; garanterar inte sensorfrekvens.
- Exponentiellt glidande medelvärde: `y_t=alpha*x_t+(1-alpha)*y_(t-1)`; alpha 0.7/0.35/0.12.
- Robust lägesmått: median; spridning `sigma_robust=1.4826*median(|x-median(x)|)` med golv 0.2 µT.
- Standardiserad skillnad: `z=|median_new-median_ref|/sqrt(sigma_ref²+sigma_new²)`.
- Visningsindex: `100*(1-exp(-z/4))`, avrundat och begränsat 0–100. **Ej sannolikhet**, ej statistiskt kalibrerad, kan ge falsklarm.
- Footprint: stegbaserad uppskattning `dx=L*sin(theta)`, `dy=-L*cos(theta)`. Drift och felaktig kompass påverkar.

Det som återstår: validerad sensorfusion, rotationskompensering, positionsmatchning, Wi-Fi/BLE-insamling, ARCore, testdata och mätning av falsklarm. Inga sådana funktioner ska påstås vara implementerade.
